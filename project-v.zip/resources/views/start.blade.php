@extends('welcome')
@section('content') 
<div class="jumbotron">
    <h1 class="display-4">Привет, Друг!</h1>
    <p class="lead">В нашем приложении можно получить нужную тебе вещь!</p>
    <hr class="my-4">
    <p>Обменяй карму на нужный товар.</p>
    <p class="lead">
      <a class="btn btn-primary btn-lg" href="#" role="button">Узнать больше!</a>
    </p>
  </div>
  @endsection