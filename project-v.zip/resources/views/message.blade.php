@extends('products')
@section('message')
<div class="alert alert-danger" role="alert">
    Внимание! Это сообщение для разработчиков!
  </div>
@endsection