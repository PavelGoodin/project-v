
<?php $__env->startSection('content'); ?> 
<div class="card-deck mb-3">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
                <div class="card">
                        <img src="<?php echo e($product->foto); ?>" class="card-img-top" alt="нет фото" width="200px" height="250px">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->title); ?></h5>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                            <span>
                            <h5><?php echo e($product->retail_price); ?></h5>
                            <img src= "<?php echo e(URL::asset('resources/img/kk.png')); ?>" alt="" width="40" height="40" style=" margin: 0px 0px 0px 0px">
                            </span>
                            
                        </div>
                        <div class="card-footer">
                            
                            <small class="text-muted">оценка 5</small>
                            <a href="#" class="btn btn-secondary btn-sm">Подробнее</a>
                        </div>
                </div>

           
       
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project-v\resources\views/products.blade.php ENDPATH**/ ?>