
<?php $__env->startSection('content'); ?> 
    <h1>Личные кабинет</h1>
    <ul>
    <li>Имя -> <?php echo e($user->name); ?></li>    
    <li>Почта -> <?php echo e($user->email); ?></li>
    <li>Адрес -></li>
    <li>Телефон -></li>
    <li></li>
    <li></li>
    </ul>
    <h2>Мои товары</h2>
    <div>
        <h3>product</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project-v\resources\views/profile.blade.php ENDPATH**/ ?>