
<?php $__env->startSection('content'); ?> 
<div class="jumbotron">
    <h1 class="display-4">Привет, Друг!</h1>
    <p class="lead">В нашем приложении можно получить нужную тебе вещь!</p>
    <hr class="my-4">
    <p>Обменяй карму на нужный товар.</p>
    <p class="lead">
      <a class="btn btn-primary btn-lg" href="#" role="button">Узнать больше!</a>
    </p>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project-v\resources\views/start.blade.php ENDPATH**/ ?>