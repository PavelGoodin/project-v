@extends('welcome')
@section('content') 
    <h1>Личные кабинет</h1>
    <ul>
    <li>Ник</li>
    <li>Уровень корабля</li>
    <li>Ранг</li>
    <li>Адрес</li>
    <li>Телефон</li>
    </ul>
    <h2>Мои товары</h2>
    <div>
        <h3>product</h3>
    </div>
@endsection
