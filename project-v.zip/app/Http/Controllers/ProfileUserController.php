<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class ProfileUserController extends Controller
{
    //
    public  function index() {

        $user = User::find(1);

        return view('profile',compact('user'));
    }
}
