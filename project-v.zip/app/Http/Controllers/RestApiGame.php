<?php

namespace App\Http\Controllers;

use App\Models\UserGame;

class RestApiGame extends Controller
{
        //
        public  function index() {

            return UserGame::all();
        }

        public  function get_user_id(int $id) {

            return UserGame::find($id);
        }
}
